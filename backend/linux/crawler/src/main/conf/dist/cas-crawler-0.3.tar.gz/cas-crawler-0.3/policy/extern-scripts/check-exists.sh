#!/bin/sh

if [ ! -f $1 ]; then
	exit 1
fi
